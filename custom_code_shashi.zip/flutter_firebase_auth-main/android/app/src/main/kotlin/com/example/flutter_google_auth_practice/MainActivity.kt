package com.example.flutter_google_auth_practice

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
